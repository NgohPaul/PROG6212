﻿using CMCS.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Linq;

namespace CMCS.Controllers
{
    public class ClaimsController : Controller
    {
        private const long MaxFileSize = 5 * 1024 * 1024; 

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ClaimViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            
            if (model.SupportingFile == null || model.SupportingFile.Length == 0)
            {
                ViewBag.FileError = "Please upload a supporting document before submitting.";
                return View(model);
            }

            
            var fileExtension = Path.GetExtension(model.SupportingFile.FileName).ToLower();
            if (fileExtension != ".pdf")
            {
                ViewBag.FileError = "Only PDF files are allowed.";
                return View(model);
            }

            
            if (model.SupportingFile.Length > MaxFileSize)
            {
                ViewBag.FileError = "File size exceeds the 5MB limit.";
                return View(model);
            }

            try
            {
                
                model.TotalAmount = model.HoursWorked * model.HourlyRate;
                model.Status = "Submitted";
                model.SubmittedDate = DateTime.Now;

                
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                if (!Directory.Exists(uploadsFolder))
                    Directory.CreateDirectory(uploadsFolder);

                var uniqueFileName = Guid.NewGuid().ToString() + "_" + model.SupportingFile.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    model.SupportingFile.CopyTo(stream);
                }

                model.DocumentPath = "/uploads/" + uniqueFileName;
                model.FileName = uniqueFileName;

                
                ClaimData.Claims.Add(model);

                TempData["SuccessMessage"] = "Claim submitted successfully!";
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                
                TempData["ErrorMessage"] = $"An error occurred while uploading your document: {ex.Message}";
                return View(model);
            }
        }

        [HttpPost]
        public IActionResult Approve(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Approved";
                claim.ApprovedDate = DateTime.Now;
            }
            return RedirectToAction("Index", "Coordinator");
        }

        [HttpPost]
        public IActionResult Reject(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Rejected";
            }
            return RedirectToAction("Index", "Coordinator");
        }
    }
}
