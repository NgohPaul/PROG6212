﻿
using Microsoft.AspNetCore.Mvc;
using CMCS.Models;
using System.Linq;

namespace CMCS.Controllers
{
    public class CoordinatorController : Controller
    {
        
        [HttpGet]
        public IActionResult Index()
        {
            
            var claimsToReview = ClaimData.Claims
                .Where(c => c.Status == "Submitted")
                .ToList();

            return View(claimsToReview);
        }

        [HttpGet]
        public IActionResult Review(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim == null) return NotFound();
            return View(claim);
        }

        [HttpPost]
        public IActionResult Approve(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null && claim.Status == "Submitted")
            {
                claim.Status = "Approved by Coordinator";
                claim.ApprovedDate = System.DateTime.Now;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Reject(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null && claim.Status == "Submitted")
            {
                claim.Status = "Rejected by Coordinator";
                claim.ApprovedDate = System.DateTime.Now;
            }
            return RedirectToAction("Index");
        }
    }
}
