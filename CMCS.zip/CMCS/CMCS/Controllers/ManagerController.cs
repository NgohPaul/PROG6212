﻿
using Microsoft.AspNetCore.Mvc;
using CMCS.Models;
using System.Linq;

namespace CMCS.Controllers
{
    public class ManagerController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(ClaimData.Claims.Where(c => c.Status.Contains("Coordinator")).ToList());
        }

        [HttpPost]
        public IActionResult FinalApprove(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Approved by Manager";
                claim.ApprovedDate = System.DateTime.Now;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Reject(string id)
        {
            var claim = ClaimData.Claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = "Rejected by Manager";
                claim.ApprovedDate = System.DateTime.Now;
            }
            return RedirectToAction("Index");
        }
    }
}

