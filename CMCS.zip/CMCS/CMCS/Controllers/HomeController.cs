﻿

using System.Diagnostics;
using CMCS.Models;
using Microsoft.AspNetCore.Mvc;

namespace CMCS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var claims = ClaimData.Claims;

            var pending = claims.Count(c => c.Status == "Pending" || c.Status == "Submitted");
            var approved = claims.Count(c => c.Status == "Approved");
            var rejected = claims.Count(c => c.Status == "Rejected");
            var total = claims.Count;

            var recent = claims.OrderByDescending(c => c.SubmittedDate)
                               .Take(3)
                               .ToList();

            ViewBag.Pending = pending;
            ViewBag.Approved = approved;
            ViewBag.Rejected = rejected;
            ViewBag.Total = total;
            ViewBag.RecentClaims = recent;

            return View();
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() =>
            View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
