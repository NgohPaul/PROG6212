﻿using System.Collections.Generic;

namespace CMCS.Models
{
    public static class ClaimData
    {
        public static List<ClaimViewModel> Claims { get; set; } = new List<ClaimViewModel>();
    }
}
