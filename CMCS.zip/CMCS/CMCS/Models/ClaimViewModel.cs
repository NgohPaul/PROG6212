﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace CMCS.Models
{
    public class ClaimViewModel
    {
        public string ClaimId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [Display(Name = "Lecturer Name")]
        public string LecturerName { get; set; }

        [Required]
        [Display(Name = "Claim Month")]
        public string ClaimMonth { get; set; }

        [Required]
        [Display(Name = "Contract Type")]
        public string ContractType { get; set; }

        [Required]
        [Range(1, 200, ErrorMessage = "Hours worked must be between 1 and 200")]
        [Display(Name = "Hours Worked")]
        public int HoursWorked { get; set; }

        [Required]
        [Range(1, 10000, ErrorMessage = "Please enter a valid hourly rate")]
        [Display(Name = "Hourly Rate")]
        public decimal HourlyRate { get; set; }

        [Display(Name = "Total Amount")]
        public decimal TotalAmount { get; set; }

        [Display(Name = "Description / Notes")]
        public string Notes { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; } = "Submitted";

        [Display(Name = "Submitted Date")]
        public DateTime SubmittedDate { get; set; } = DateTime.Now;

        [Display(Name = "Approved Date")]
        public DateTime? ApprovedDate { get; set; }

        [Required(ErrorMessage = "A supporting document (PDF) is required.")]
        [Display(Name = "Supporting Document")]
        public IFormFile? SupportingFile { get; set; }

        public string? DocumentPath { get; set; }

        public string? FileName { get; set; }
    }
}
